# Minimal Launcher

A lightweight Android home screen: frosted-glass background with adjustable blur, faded icons,
a minimal home, and a categorised app drawer. No third-party libraries, no XML layouts,
no background services.

**Status:** written but not yet compiled or run on a device (it was produced without an Android
SDK). Expect to fix a small compile error or two on first build, and please test on your phone.

## Build and install

1. Install Android Studio (needs JDK 17, bundled with recent versions).
2. Open this folder (`MinimalLauncher`) in Android Studio and let Gradle sync.
   It will download Android Gradle Plugin 8.5.2 and Gradle 8.7 on its own.
3. Plug in your phone (USB debugging on) and press Run, or build an APK:
   `Build > Build APK(s)`. For the smallest, fastest version use the **release** variant:
   `Build > Select Build Variant > release` (it is shrunk with R8 and signed with the debug key,
   which is fine for personal use).
4. On the phone press Home and choose **Minimal Launcher** > Always.

Minimum Android version: 8.0 (API 26). Live blur needs Android 12+.

## What it does

| Feature | How |
|---|---|
| Frosted glass | Android 12+: real-time window blur. Older / blur disabled: a tiny scaled-up wallpaper copy. Levels: Off, Low, Medium, High, Max. Home is lightly blurred, the drawer more so. |
| Faded icons | Icon style Original / Faded / Mono with a strength slider. In dark mode icons are brightened slightly so they stay visible. |
| Dark mode | System / Light / Dark. |
| Fonts | 8 built-in fonts (no font files shipped), applied across the whole launcher. |
| Home | Clock, date, up to 6 pinned apps, "All apps". |
| Drawer | Search, Categories view (collapsible sections) or A-Z view with a fast-scroll strip. |
| Categories | Automatic (Android category + package-name hints), movable per app, custom categories. |
| App menu (long-press) | Pin to home, hide, change category, app info, uninstall. |

## Gestures

- Swipe up on home: open the drawer
- Swipe down in the drawer (when at the top), Back or Home: close it
- Long-press empty home space (or the three dots in the drawer): settings, wallpaper
- Search then press Go: launches the first result

## Limits

- The font and theme options change **this launcher only**. Android does not let a launcher
  restyle the system UI, notification shade or other apps.
- Double-tap to lock is not included (it needs a device-admin or accessibility permission).
- Hidden apps are still found by search, by design.

## Why it is light

- Zero dependencies; Kotlin stdlib only. R8 shrinks the release build.
- App list is loaded once and refreshed only when an app is installed, removed or updated.
- Icons load on demand into a hard-capped 4 MB cache.
- One background thread that exits when idle.
- The clock is a stock `TextClock` (updates once a minute). Nothing polls.

## Files

- `MainActivity.kt` home screen, drawer, gestures, menus
- `SettingsActivity.kt` settings screen
- `DrawerAdapter.kt` drawer rows and the A-Z index strip
- `Style.kt` colours, fonts, blur levels, icon filter
- `Frost.kt` window blur, edge-to-edge setup, old-phone blur fallback
- `AppRepository.kt` app list and categories
- `IconLoader.kt` lazy icon cache
- `Prefs.kt` saved settings
