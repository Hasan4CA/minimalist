package com.minimal.launcher

import java.util.concurrent.LinkedBlockingQueue
import java.util.concurrent.ThreadPoolExecutor
import java.util.concurrent.TimeUnit

/**
 * A single background thread that exits when idle, so it costs no RAM or CPU
 * when nothing is loading.
 */
object Bg {
    private val pool = ThreadPoolExecutor(1, 1, 5, TimeUnit.SECONDS, LinkedBlockingQueue<Runnable>()).apply {
        allowCoreThreadTimeOut(true)
    }

    fun run(block: () -> Unit) {
        pool.execute {
            try {
                block()
            } catch (e: Throwable) {
                // never crash the launcher because of a background load
            }
        }
    }
}
