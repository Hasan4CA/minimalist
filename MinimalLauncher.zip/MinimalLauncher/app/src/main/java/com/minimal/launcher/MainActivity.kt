package com.minimal.launcher

import android.animation.ValueAnimator
import android.app.Activity
import android.app.AlertDialog
import android.app.WallpaperManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.util.TypedValue
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextClock
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs

/**
 * Home screen + app drawer in one activity. The whole UI is built in code (no XML layouts,
 * no AndroidX), and nothing runs while the launcher is idle.
 */
class MainActivity : Activity() {

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private lateinit var prefs: Prefs
    private lateinit var style: Style
    private lateinit var repo: AppRepository
    private lateinit var icons: IconLoader
    private lateinit var adapter: DrawerAdapter
    private lateinit var detector: GestureDetector

    private lateinit var root: FrameLayout
    private lateinit var legacyBg: ImageView
    private lateinit var scrim: View
    private lateinit var home: LinearLayout
    private lateinit var pinnedBox: LinearLayout
    private lateinit var drawer: LinearLayout
    private lateinit var search: EditText
    private lateinit var modeBtn: TextView
    private lateinit var list: ListView
    private lateinit var index: IndexBar

    private var apps: List<AppInfo> = emptyList()
    private var styleKey = ""
    private var drawerOpen = false
    private var closeEligible = false
    private var insetTop = 0
    private var insetBottom = 0
    private var windowBlur = false
    private var curBlur = 0
    private var blurAnim: ValueAnimator? = null
    private var legacyKey = ""

    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            loadApps()
        }
    }

    // ------------------------------------------------------------------ lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        style = Style(this, prefs)
        styleKey = prefs.styleKey()
        repo = AppRepository(this)
        icons = IconLoader(this, style.dp(44))

        buildUi()
        setContentView(root)
        Sys.edgeToEdge(this, root) { top, bottom ->
            insetTop = top
            insetBottom = bottom
            applyInsets()
        }
        Sys.barIcons(this, style.dark)
        applyInsets()

        detector = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onFling(e1: MotionEvent?, e2: MotionEvent, vx: Float, vy: Float): Boolean {
                if (e1 == null) return false
                val dy = e2.y - e1.y
                val dx = e2.x - e1.x
                val vertical = abs(dy) > abs(dx) * 1.5f && abs(dy) > style.dp(80)
                if (!vertical) return false
                if (!drawerOpen && dy < 0 && vy < -600f) {
                    openDrawer()
                    return true
                }
                if (drawerOpen && dy > 0 && vy > 600f && closeEligible) {
                    closeDrawer(true)
                    return true
                }
                return false
            }
        })
        detector.setIsLongpressEnabled(false)

        // Dynamic registration: only alive while the launcher process is, and zero cost when idle.
        val f = IntentFilter()
        f.addAction(Intent.ACTION_PACKAGE_ADDED)
        f.addAction(Intent.ACTION_PACKAGE_REMOVED)
        f.addAction(Intent.ACTION_PACKAGE_CHANGED)
        f.addAction(Intent.ACTION_PACKAGE_REPLACED)
        f.addDataScheme("package")
        registerReceiver(pkgReceiver, f)

        loadApps()
    }

    override fun onResume() {
        super.onResume()
        if (prefs.styleKey() != styleKey) {
            recreate() // theme, font, icon style or blur changed in settings
            return
        }
        applyBlurMode()
        refreshHome()
        refreshRows()
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        // Home button pressed while already on home: close the drawer.
        if (drawerOpen) closeDrawer(true)
    }

    override fun onStop() {
        super.onStop()
        if (drawerOpen) closeDrawer(false)
    }

    override fun onDestroy() {
        blurAnim?.cancel()
        try {
            unregisterReceiver(pkgReceiver)
        } catch (e: Exception) {
            // already unregistered
        }
        super.onDestroy()
    }

    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun onBackPressed() {
        if (drawerOpen) closeDrawer(true)
        // a launcher ignores Back on the home screen
    }

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (ev.actionMasked == MotionEvent.ACTION_DOWN) {
            val atTop = list.firstVisiblePosition == 0 && (list.getChildAt(0)?.top ?: 0) >= 0
            closeEligible = drawerOpen && atTop && ev.x < root.width - style.dp(40)
        }
        detector.onTouchEvent(ev)
        return super.dispatchTouchEvent(ev)
    }

    // ------------------------------------------------------------------ UI construction

    private fun buildUi() {
        val st = style
        root = FrameLayout(this)

        legacyBg = ImageView(this)
        legacyBg.scaleType = ImageView.ScaleType.CENTER_CROP
        legacyBg.visibility = View.GONE
        root.addView(legacyBg, FrameLayout.LayoutParams(MATCH, MATCH))

        scrim = View(this)
        scrim.setBackgroundColor(st.frostColor)
        scrim.alpha = st.scrimHome
        root.addView(scrim, FrameLayout.LayoutParams(MATCH, MATCH))

        buildHome()
        buildDrawer()
    }

    private fun buildHome() {
        val st = style
        home = LinearLayout(this)
        home.orientation = LinearLayout.VERTICAL

        val clock = TextClock(this)
        clock.format12Hour = "h:mm"
        clock.format24Hour = "HH:mm"
        clock.setTextSize(TypedValue.COMPLEX_UNIT_SP, 68f)
        clock.setTextColor(st.text)
        clock.typeface = st.clockTypeface
        clock.includeFontPadding = false
        home.addView(clock, LinearLayout.LayoutParams(WRAP, WRAP))

        val date = TextClock(this)
        date.format12Hour = "EEEE, d MMMM"
        date.format24Hour = "EEEE, d MMMM"
        date.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
        date.setTextColor(st.textDim)
        date.typeface = st.typeface
        date.includeFontPadding = false
        val dateLp = LinearLayout.LayoutParams(WRAP, WRAP)
        dateLp.topMargin = st.dp(6)
        home.addView(date, dateLp)

        pinnedBox = LinearLayout(this)
        pinnedBox.orientation = LinearLayout.VERTICAL
        val pinLp = LinearLayout.LayoutParams(MATCH, WRAP)
        pinLp.topMargin = st.dp(40)
        home.addView(pinnedBox, pinLp)

        home.addView(View(this), LinearLayout.LayoutParams(MATCH, 0, 1f))

        val all = st.label(this, "All apps", 14f, st.textDim)
        all.gravity = Gravity.CENTER
        all.letterSpacing = 0.1f
        all.setPadding(0, st.dp(14), 0, st.dp(14))
        all.setOnClickListener { openDrawer() }
        home.addView(all, LinearLayout.LayoutParams(MATCH, WRAP))

        home.setOnLongClickListener {
            showHomeMenu()
            true
        }
        root.addView(home, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    private fun buildDrawer() {
        val st = style
        drawer = LinearLayout(this)
        drawer.orientation = LinearLayout.VERTICAL
        drawer.visibility = View.GONE

        // ---- top bar: search, layout toggle, menu
        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setPadding(st.dp(24), 0, st.dp(12), 0)

        search = EditText(this)
        search.hint = "Search apps"
        search.setHintTextColor(st.textFaint)
        search.setTextColor(st.text)
        search.typeface = st.typeface
        search.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18f)
        search.background = null
        search.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        search.setSingleLine(true)
        search.imeOptions = EditorInfo.IME_ACTION_GO
        search.setPadding(st.dp(4), st.dp(14), st.dp(4), st.dp(14))
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                refreshRows()
            }
        })
        search.setOnEditorActionListener { _, _, _ ->
            val first = adapter.rows.firstOrNull { it is Row.App } as? Row.App
            if (first != null) launch(first.app)
            true
        }
        bar.addView(search, LinearLayout.LayoutParams(0, WRAP, 1f))

        modeBtn = st.label(this, modeText(), 13f, st.textDim)
        modeBtn.setPadding(st.dp(12), st.dp(12), st.dp(12), st.dp(12))
        modeBtn.setOnClickListener {
            prefs.drawerMode = if (prefs.drawerMode == Prefs.MODE_AZ) Prefs.MODE_CATEGORIES else Prefs.MODE_AZ
            modeBtn.text = modeText()
            refreshRows()
            list.setSelection(0)
        }
        bar.addView(modeBtn)

        val menu = st.label(this, "⋮", 20f, st.textDim)
        menu.setPadding(st.dp(12), st.dp(8), st.dp(12), st.dp(8))
        menu.setOnClickListener { showHomeMenu() }
        bar.addView(menu)

        drawer.addView(bar, LinearLayout.LayoutParams(MATCH, WRAP))

        // ---- list + A-Z index
        val body = FrameLayout(this)
        adapter = DrawerAdapter(this, st, icons)

        list = ListView(this)
        list.divider = null
        list.dividerHeight = 0
        list.selector = ColorDrawable(Color.TRANSPARENT)
        list.isVerticalScrollBarEnabled = false
        list.overScrollMode = View.OVER_SCROLL_NEVER
        list.clipToPadding = false
        list.adapter = adapter
        list.setOnItemClickListener { _, _, pos, _ ->
            onRowClick(adapter.rows[pos])
        }
        list.setOnItemLongClickListener { _, _, pos, _ ->
            val r = adapter.rows[pos]
            if (r is Row.App) {
                showAppMenu(r.app)
                true
            } else {
                false
            }
        }
        body.addView(list, FrameLayout.LayoutParams(MATCH, MATCH))

        index = IndexBar(this, st)
        index.onPick = { letter ->
            val p = adapter.rows.indexOfFirst { it is Row.Header && it.title == letter }
            if (p >= 0) list.setSelection(p)
        }
        val idxLp = FrameLayout.LayoutParams(st.dp(28), MATCH, Gravity.END)
        idxLp.topMargin = st.dp(16)
        idxLp.bottomMargin = st.dp(16)
        body.addView(index, idxLp)

        drawer.addView(body, LinearLayout.LayoutParams(MATCH, 0, 1f))
        root.addView(drawer, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    private fun applyInsets() {
        val st = style
        home.setPadding(st.dp(28), insetTop + st.dp(72), st.dp(28), insetBottom + st.dp(12))
        drawer.setPadding(0, insetTop + st.dp(8), 0, 0)
        list.setPadding(0, 0, 0, insetBottom + st.dp(16))
    }

    private fun modeText(): String = if (prefs.drawerMode == Prefs.MODE_AZ) "A–Z" else "Categories"

    // ------------------------------------------------------------------ data

    private fun loadApps() {
        Bg.run {
            val loaded = repo.load()
            runOnUiThread {
                if (isDestroyed) return@runOnUiThread
                apps = loaded
                refreshHome()
                refreshRows()
            }
        }
    }

    private fun categoryOf(app: AppInfo): String = prefs.categoryOf(app.key) ?: app.category

    private fun letterOf(app: AppInfo): String {
        val c = app.label.trim().firstOrNull()?.uppercaseChar()
        return if (c != null && c.isLetter()) c.toString() else "#"
    }

    private fun refreshRows() {
        val q = search.text.toString().trim().lowercase()
        val rows = ArrayList<Row>()
        var letters: List<String> = emptyList()

        if (q.isNotEmpty()) {
            // search covers every app, including hidden ones
            apps.filter { it.sortKey.contains(q) }
                .sortedBy { !it.sortKey.startsWith(q) }
                .forEach { rows.add(Row.App(it)) }
        } else {
            val hidden = prefs.hidden
            val shown = apps.filter { !hidden.contains(it.key) }

            if (prefs.drawerMode == Prefs.MODE_AZ) {
                val groups = shown.groupBy { letterOf(it) }
                val keys = groups.keys.sortedWith(compareBy<String>({ it == "#" }, { it }))
                for (k in keys) {
                    rows.add(Row.Header(k, -1, false, false))
                    groups[k]!!.forEach { rows.add(Row.App(it)) }
                }
                letters = keys
            } else {
                val collapsed = prefs.collapsed
                val groups = shown.groupBy { categoryOf(it) }
                val keys = groups.keys.sortedWith(compareBy<String>({ Categories.rank(it) }, { it }))
                for (k in keys) {
                    val members = groups[k]!!
                    val isCollapsed = collapsed.contains(k)
                    rows.add(Row.Header(k, members.size, isCollapsed, true))
                    if (!isCollapsed) members.forEach { rows.add(Row.App(it)) }
                }
            }
        }

        index.letters = letters
        index.visibility = if (letters.isEmpty()) View.GONE else View.VISIBLE
        adapter.submit(rows)
    }

    private fun refreshHome() {
        val st = style
        pinnedBox.removeAllViews()
        val byKey = apps.associateBy { it.key }
        for (k in prefs.pinned) {
            val app = byKey[k] ?: continue
            pinnedBox.addView(pinnedRow(app))
        }
        if (pinnedBox.childCount == 0) {
            pinnedBox.addView(st.label(this, "Long-press an app in the drawer to pin it here", 13f, st.textFaint))
        }
    }

    private fun pinnedRow(app: AppInfo): View {
        val st = style
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(0, st.dp(9), st.dp(16), st.dp(9))
        row.background = st.pressed()

        val icon = ImageView(this)
        icon.colorFilter = st.iconFilter
        icon.imageAlpha = st.iconAlpha
        row.addView(icon, LinearLayout.LayoutParams(st.dp(36), st.dp(36)))
        icons.load(app, icon)

        val name = st.label(this, app.label, 20f, st.text)
        val lp = LinearLayout.LayoutParams(WRAP, WRAP)
        lp.leftMargin = st.dp(18)
        row.addView(name, lp)

        row.setOnClickListener { launch(app) }
        row.setOnLongClickListener {
            showAppMenu(app)
            true
        }
        return row
    }

    // ------------------------------------------------------------------ drawer open / close

    private fun openDrawer() {
        if (drawerOpen) return
        drawerOpen = true
        drawer.visibility = View.VISIBLE
        drawer.alpha = 0f
        drawer.translationY = style.dp(48).toFloat()
        drawer.animate().alpha(1f).translationY(0f).setDuration(200).start()
        home.animate().alpha(0f).setDuration(140).withEndAction {
            if (drawerOpen) home.visibility = View.INVISIBLE
        }.start()
        scrim.animate().alpha(style.scrimDrawer).setDuration(200).start()
        setBlur(style.blurPx, true)
    }

    private fun closeDrawer(animate: Boolean) {
        if (!drawerOpen) return
        drawerOpen = false
        hideKeyboard()
        search.setText("")
        home.visibility = View.VISIBLE
        list.setSelection(0)

        if (animate) {
            home.animate().alpha(1f).setDuration(200).start()
            drawer.animate().alpha(0f).translationY(style.dp(48).toFloat()).setDuration(160).withEndAction {
                if (!drawerOpen) drawer.visibility = View.GONE
            }.start()
            scrim.animate().alpha(style.scrimHome).setDuration(200).start()
        } else {
            home.animate().cancel()
            drawer.animate().cancel()
            scrim.animate().cancel()
            home.alpha = 1f
            drawer.visibility = View.GONE
            scrim.alpha = style.scrimHome
        }
        setBlur(style.blurPx / 3, animate)
    }

    private fun hideKeyboard() {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(search.windowToken, 0)
    }

    // ------------------------------------------------------------------ blur

    private fun applyBlurMode() {
        val canBlur = Frost.windowBlurSupported(this)
        windowBlur = canBlur && style.blurLevel > 0
        val target = if (drawerOpen) style.blurPx else style.blurPx / 3
        curBlur = if (windowBlur) target else 0
        Frost.set(this, curBlur)

        if (!windowBlur && style.blurLevel > 0) {
            loadLegacyBlur()
        } else {
            legacyBg.visibility = View.GONE
        }
    }

    private fun setBlur(target: Int, animate: Boolean) {
        if (!windowBlur) return
        blurAnim?.cancel()
        if (!animate || curBlur == target) {
            curBlur = target
            Frost.set(this, target)
            return
        }
        val a = ValueAnimator.ofInt(curBlur, target)
        a.duration = 220
        a.addUpdateListener {
            curBlur = it.animatedValue as Int
            Frost.set(this@MainActivity, curBlur)
        }
        blurAnim = a
        a.start()
    }

    /** Pre-Android-12 fallback: a tiny, scaled-up copy of the wallpaper. */
    private fun loadLegacyBlur() {
        val id = try {
            WallpaperManager.getInstance(this).getWallpaperId(WallpaperManager.FLAG_SYSTEM)
        } catch (e: Exception) {
            -1
        }
        val key = "${style.blurLevel}:$id"
        if (key == legacyKey) {
            legacyBg.visibility = if (legacyBg.drawable != null) View.VISIBLE else View.GONE
            return
        }
        legacyKey = key
        val level = style.blurLevel
        val dm = resources.displayMetrics
        Bg.run {
            val bmp = LegacyBlur.make(this, level, dm.widthPixels, dm.heightPixels)
            runOnUiThread {
                if (isDestroyed || legacyKey != key) return@runOnUiThread
                legacyBg.setImageBitmap(bmp)
                legacyBg.visibility = if (bmp != null) View.VISIBLE else View.GONE
            }
        }
    }

    // ------------------------------------------------------------------ actions

    private fun onRowClick(r: Row) {
        when (r) {
            is Row.App -> launch(r.app)
            is Row.Header -> {
                if (r.collapsible) {
                    val c = prefs.collapsed.toMutableSet()
                    if (!c.add(r.title)) c.remove(r.title)
                    prefs.collapsed = c
                    refreshRows()
                }
            }
        }
    }

    private fun launch(app: AppInfo) {
        val i = Intent(Intent.ACTION_MAIN)
            .addCategory(Intent.CATEGORY_LAUNCHER)
            .setComponent(app.component)
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED)
        try {
            startActivity(i)
        } catch (e: Exception) {
            Toast.makeText(this, "Can't open " + app.label, Toast.LENGTH_SHORT).show()
        }
    }

    private fun startSafe(i: Intent) {
        try {
            startActivity(i)
        } catch (e: Exception) {
            Toast.makeText(this, "Not available on this phone", Toast.LENGTH_SHORT).show()
        }
    }

    private fun dlg(): Int =
        if (style.dark) android.R.style.Theme_DeviceDefault_Dialog_Alert
        else android.R.style.Theme_DeviceDefault_Light_Dialog_Alert

    private fun showHomeMenu() {
        val items = arrayOf("Launcher settings", "Wallpaper", "System settings")
        AlertDialog.Builder(this, dlg()).setItems(items) { _, which ->
            when (which) {
                0 -> startActivity(Intent(this, SettingsActivity::class.java))
                1 -> startSafe(Intent.createChooser(Intent(Intent.ACTION_SET_WALLPAPER), "Wallpaper"))
                2 -> startSafe(Intent(Settings.ACTION_SETTINGS))
                else -> {}
            }
        }.show()
    }

    private fun showAppMenu(app: AppInfo) {
        val isPinned = prefs.pinned.contains(app.key)
        val isHidden = prefs.hidden.contains(app.key)
        val items = arrayOf(
            if (isPinned) "Remove from home" else "Pin to home",
            if (isHidden) "Unhide" else "Hide",
            "Change category",
            "App info",
            "Uninstall"
        )
        AlertDialog.Builder(this, dlg()).setTitle(app.label).setItems(items) { _, which ->
            when (which) {
                0 -> togglePin(app)
                1 -> {
                    val h = prefs.hidden.toMutableSet()
                    if (!h.add(app.key)) h.remove(app.key)
                    prefs.hidden = h
                    refreshRows()
                }
                2 -> showCategoryDialog(app)
                3 -> startSafe(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + app.pkg)))
                4 -> startSafe(Intent(Intent.ACTION_DELETE, Uri.parse("package:" + app.pkg)))
                else -> {}
            }
        }.show()
    }

    private fun togglePin(app: AppInfo) {
        val p = prefs.pinned.toMutableList()
        if (p.contains(app.key)) {
            p.remove(app.key)
        } else if (p.size >= Prefs.MAX_PINNED) {
            Toast.makeText(this, "Home holds " + Prefs.MAX_PINNED + " apps", Toast.LENGTH_SHORT).show()
            return
        } else {
            p.add(app.key)
        }
        prefs.pinned = p
        refreshHome()
    }

    private fun showCategoryDialog(app: AppInfo) {
        val names = ArrayList<String>(Categories.ALL)
        names.add("New category…")
        names.add("Automatic")
        AlertDialog.Builder(this, dlg()).setTitle("Category").setItems(names.toTypedArray()) { _, which ->
            when (which) {
                names.size - 1 -> prefs.setCategory(app.key, null)
                names.size - 2 -> askNewCategory(app)
                else -> prefs.setCategory(app.key, names[which])
            }
            refreshRows()
        }.show()
    }

    private fun askNewCategory(app: AppInfo) {
        val input = EditText(this)
        input.setSingleLine(true)
        input.hint = "Category name"
        val pad = style.dp(20)
        input.setPadding(pad, pad, pad, pad)
        AlertDialog.Builder(this, dlg())
            .setTitle("New category")
            .setView(input)
            .setPositiveButton("Add") { _, _ ->
                val name = input.text.toString().trim().take(20)
                if (name.isNotEmpty()) {
                    prefs.setCategory(app.key, name)
                    refreshRows()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
