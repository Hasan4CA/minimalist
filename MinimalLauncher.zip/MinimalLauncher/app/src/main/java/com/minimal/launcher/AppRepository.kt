package com.minimal.launcher

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo

data class AppInfo(
    val label: String,
    val pkg: String,
    val component: ComponentName,
    /** Category guessed automatically; the user can override it (see Prefs.categoryOf). */
    val category: String
) {
    val key: String = component.flattenToString()
    val sortKey: String = label.lowercase()
}

object Categories {
    const val ESSENTIALS = "Essentials"
    const val SOCIAL = "Social"
    const val MEDIA = "Media"
    const val PHOTOS = "Photos"
    const val PRODUCTIVITY = "Productivity"
    const val GAMES = "Games"
    const val TRAVEL = "Maps & Travel"
    const val NEWS = "News"
    const val SHOPPING = "Shopping"
    const val FINANCE = "Finance"
    const val OTHER = "Other"

    /** Display order, and the choices offered when moving an app. */
    val ALL = listOf(
        ESSENTIALS, SOCIAL, MEDIA, PHOTOS, PRODUCTIVITY, GAMES, TRAVEL, NEWS, SHOPPING, FINANCE, OTHER
    )

    fun rank(c: String): Int = when {
        c == OTHER -> 1000
        ALL.contains(c) -> ALL.indexOf(c)
        else -> 500 // user-made categories sit just before "Other"
    }

    // Many apps declare no category, so fall back to simple package-name hints.
    private val HINTS: List<Pair<String, List<String>>> = listOf(
        ESSENTIALS to listOf(
            "dialer", "incallui", "contacts", "telecom", "mms", "messaging", "settings",
            "calculator", "deskclock", "clock", "calendar", "documentsui", "filemanager", "files"
        ),
        SOCIAL to listOf(
            "whatsapp", "telegram", "facebook", "instagram", "twitter", "snapchat", "messenger",
            "signal", "tiktok", "discord", "reddit", "linkedin", "pinterest"
        ),
        MEDIA to listOf("youtube", "spotify", "music", "netflix", "video", "podcast", "radio", "soundcloud", "vlc"),
        PHOTOS to listOf("camera", "gallery", "photos", "snapseed"),
        PRODUCTIVITY to listOf("docs", "sheets", "slides", "office", "notes", "keep", "drive", "dropbox", "onenote", "notion"),
        TRAVEL to listOf("maps", "uber", "careem", "transit", "navigation"),
        SHOPPING to listOf("amazon", "daraz", "ebay", "aliexpress"),
        FINANCE to listOf("bank", "wallet", "paypal", "easypaisa", "jazzcash", "sadapay", "nayapay")
    )

    @Suppress("DEPRECATION")
    fun auto(ai: ApplicationInfo): String {
        val byFlag = when (ai.category) {
            ApplicationInfo.CATEGORY_GAME -> GAMES
            ApplicationInfo.CATEGORY_AUDIO, ApplicationInfo.CATEGORY_VIDEO -> MEDIA
            ApplicationInfo.CATEGORY_IMAGE -> PHOTOS
            ApplicationInfo.CATEGORY_SOCIAL -> SOCIAL
            ApplicationInfo.CATEGORY_NEWS -> NEWS
            ApplicationInfo.CATEGORY_MAPS -> TRAVEL
            ApplicationInfo.CATEGORY_PRODUCTIVITY -> PRODUCTIVITY
            else -> null
        }
        if (byFlag != null) return byFlag
        if (ai.flags and ApplicationInfo.FLAG_IS_GAME != 0) return GAMES

        val p = ai.packageName.lowercase()
        for ((cat, words) in HINTS) {
            if (words.any { p.contains(it) }) return cat
        }
        return OTHER
    }
}

class AppRepository(private val ctx: Context) {

    /** Reads the launchable apps once; callers cache the result and reload only on package changes. */
    fun load(): List<AppInfo> {
        val pm = ctx.packageManager
        val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val out = ArrayList<AppInfo>()
        for (ri in pm.queryIntentActivities(query, 0)) {
            val ai = ri.activityInfo ?: continue
            if (ai.packageName == ctx.packageName) continue
            val cn = ComponentName(ai.packageName, ai.name)
            val label = ri.loadLabel(pm).toString()
            out.add(AppInfo(label, ai.packageName, cn, Categories.auto(ai.applicationInfo)))
        }
        out.sortBy { it.sortKey }
        return out
    }
}
