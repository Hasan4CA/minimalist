package com.minimal.launcher

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Paint
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast

/** Every change applies instantly; the home screen picks it up when you go back. */
class SettingsActivity : Activity() {

    private val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    private val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    private lateinit var prefs: Prefs
    private lateinit var style: Style
    private lateinit var icons: IconLoader
    private lateinit var scrim: View
    private lateinit var scroll: ScrollView
    private lateinit var content: LinearLayout
    private lateinit var previewRow: LinearLayout

    private var apps: List<AppInfo> = emptyList()
    private var windowBlurOk = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)
        style = Style(this, prefs)
        icons = IconLoader(this, style.dp(44))
        windowBlurOk = Frost.windowBlurSupported(this)

        build(savedInstanceState?.getInt("sy") ?: 0)

        Bg.run {
            val loaded = AppRepository(this).load()
            runOnUiThread {
                if (isDestroyed) return@runOnUiThread
                apps = loaded
                refreshPreview()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        applyFrost()
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putInt("sy", scroll.scrollY)
    }

    private fun applyFrost() {
        scrim.alpha = style.scrimDrawer
        Frost.set(this, style.blurPx)
    }

    // ------------------------------------------------------------------ layout

    private fun build(scrollY: Int) {
        val st = style
        val root = FrameLayout(this)

        scrim = View(this)
        scrim.setBackgroundColor(st.frostColor)
        root.addView(scrim, FrameLayout.LayoutParams(MATCH, MATCH))

        scroll = ScrollView(this)
        scroll.isVerticalScrollBarEnabled = false
        scroll.overScrollMode = View.OVER_SCROLL_NEVER
        scroll.clipToPadding = false

        content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        scroll.addView(content, ViewGroup.LayoutParams(MATCH, WRAP))
        root.addView(scroll, FrameLayout.LayoutParams(MATCH, MATCH))

        setContentView(root)
        Sys.edgeToEdge(this, root) { top, bottom ->
            scroll.setPadding(st.dp(28), top + st.dp(24), st.dp(28), bottom + st.dp(32))
        }
        Sys.barIcons(this, st.dark)
        scroll.setPadding(st.dp(28), st.dp(48), st.dp(28), st.dp(32))

        // ---- header
        content.addView(st.label(this, "Settings", 32f, st.text, st.clockTypeface))
        content.addView(spaced(st.label(this, "Changes apply instantly.", 13f, st.textDim), 4))

        // ---- appearance
        section("Appearance")
        content.addView(chips("Theme", arrayOf("System", "Light", "Dark"), prefs.theme) {
            prefs.theme = it
            recreate()
        })
        content.addView(fontRow())

        // ---- frosted glass
        section("Frosted glass")
        content.addView(
            slider("Background blur", 4, prefs.blurLevel, { Style.BLUR_LABELS[it] }) { level ->
                prefs.blurLevel = level
                style = Style(this, prefs)
                applyFrost()
            }
        )
        if (!windowBlurOk) {
            content.addView(
                spaced(
                    st.label(
                        this,
                        "Live blur needs Android 12+ with effects enabled. " +
                            "On this phone the launcher uses a lightweight wallpaper blur instead.",
                        12f, st.textFaint
                    ), 2
                )
            )
        }

        // ---- icons
        section("Icons")
        previewRow = LinearLayout(this)
        previewRow.orientation = LinearLayout.HORIZONTAL
        content.addView(previewRow, LinearLayout.LayoutParams(WRAP, WRAP))
        content.addView(chips("Icon style", arrayOf("Original", "Faded", "Mono"), prefs.iconStyle) {
            prefs.iconStyle = it
            style = Style(this, prefs)
            refreshPreview()
        })
        content.addView(
            slider("Fade strength", 100, prefs.iconStrength, { "$it%" }) { v ->
                prefs.iconStrength = v
                style = Style(this, prefs)
                refreshPreview()
            }
        )

        // ---- drawer
        section("App drawer")
        content.addView(chips("Layout", arrayOf("Categories", "A–Z"), prefs.drawerMode) {
            prefs.drawerMode = it
        })
        content.addView(action("Hidden apps", "Hide apps from the drawer (search still finds them)") {
            hiddenDialog()
        })
        content.addView(action("Reset categories", "Go back to automatic categories") {
            prefs.clearCategories()
            Toast.makeText(this, "Categories reset", Toast.LENGTH_SHORT).show()
        })

        // ---- system
        section("System")
        content.addView(action("Default launcher", "Make this your home app") {
            try {
                startActivity(Intent(Settings.ACTION_HOME_SETTINGS))
            } catch (e: Exception) {
                Toast.makeText(this, "Open Settings > Apps > Default apps > Home app", Toast.LENGTH_LONG).show()
            }
        })
        content.addView(
            spaced(
                st.label(
                    this,
                    "The font setting changes this launcher only. Android does not let a launcher " +
                        "change the system font, notification shade or other apps.",
                    12f, st.textFaint
                ), 14
            )
        )

        scroll.post { scroll.scrollTo(0, scrollY) }
        applyFrost()
    }

    // ------------------------------------------------------------------ building blocks

    private fun spaced(v: View, topDp: Int): View {
        val lp = LinearLayout.LayoutParams(WRAP, WRAP)
        lp.topMargin = style.dp(topDp)
        v.layoutParams = lp
        return v
    }

    private fun section(title: String) {
        val tv = style.label(this, title.uppercase(), 12f, style.textDim)
        tv.letterSpacing = 0.14f
        content.addView(spaced(tv, 34))
    }

    private fun chips(title: String, options: Array<String>, current: Int, onPick: (Int) -> Unit): View {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(0, style.dp(12), 0, style.dp(4))
        box.addView(style.label(this, title, 17f, style.text))

        val rowView = LinearLayout(this)
        rowView.orientation = LinearLayout.HORIZONTAL
        val views = ArrayList<TextView>()

        fun paint(selected: Int) {
            for (j in views.indices) {
                val on = j == selected
                views[j].setTextColor(if (on) style.text else style.textFaint)
                views[j].paintFlags = if (on) {
                    views[j].paintFlags or Paint.UNDERLINE_TEXT_FLAG
                } else {
                    views[j].paintFlags and Paint.UNDERLINE_TEXT_FLAG.inv()
                }
            }
        }

        for (i in options.indices) {
            val tv = style.label(this, options[i], 15f, style.textFaint)
            tv.setPadding(0, style.dp(8), style.dp(24), style.dp(8))
            tv.setOnClickListener {
                paint(i)
                onPick(i)
            }
            views.add(tv)
            rowView.addView(tv)
        }
        paint(current)
        box.addView(rowView)
        return box
    }

    private fun slider(
        title: String,
        maxValue: Int,
        progress: Int,
        valueText: (Int) -> String,
        onChange: (Int) -> Unit
    ): View {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(0, style.dp(12), 0, style.dp(4))

        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.addView(style.label(this, title, 17f, style.text), LinearLayout.LayoutParams(0, WRAP, 1f))
        val value = style.label(this, valueText(progress), 14f, style.textDim)
        head.addView(value)
        box.addView(head)

        val sb = SeekBar(this)
        sb.max = maxValue
        sb.progress = progress
        sb.progressTintList = ColorStateList.valueOf(style.text)
        sb.thumbTintList = ColorStateList.valueOf(style.text)
        sb.progressBackgroundTintList = ColorStateList.valueOf(style.textFaint)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar, p: Int, fromUser: Boolean) {
                value.text = valueText(p)
                if (fromUser) onChange(p)
            }

            override fun onStartTrackingTouch(seekBar: SeekBar) {}
            override fun onStopTrackingTouch(seekBar: SeekBar) {}
        })
        val lp = LinearLayout.LayoutParams(MATCH, WRAP)
        lp.topMargin = style.dp(6)
        box.addView(sb, lp)
        return box
    }

    private fun action(title: String, sub: String, onClick: () -> Unit): View {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(0, style.dp(14), 0, style.dp(14))
        box.background = style.pressed()
        box.addView(style.label(this, title, 17f, style.text))
        box.addView(spaced(style.label(this, sub, 13f, style.textDim), 3))
        box.setOnClickListener { onClick() }
        return box
    }

    private fun fontRow(): View {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(0, style.dp(14), 0, style.dp(8))
        box.background = style.pressed()

        val head = LinearLayout(this)
        head.orientation = LinearLayout.HORIZONTAL
        head.addView(style.label(this, "Font", 17f, style.text), LinearLayout.LayoutParams(0, WRAP, 1f))
        head.addView(style.label(this, Fonts.LABELS[prefs.font], 14f, style.textDim))
        box.addView(head)
        box.addView(spaced(style.label(this, "The quick brown fox jumps over the lazy dog", 15f, style.textDim), 6))

        box.setOnClickListener {
            AlertDialog.Builder(this, dlg())
                .setTitle("Font")
                .setSingleChoiceItems(Fonts.LABELS, prefs.font) { d, which ->
                    prefs.font = which
                    d.dismiss()
                    recreate()
                }
                .show()
        }
        return box
    }

    private fun refreshPreview() {
        val st = style
        previewRow.removeAllViews()
        for (app in apps.take(5)) {
            val iv = ImageView(this)
            iv.colorFilter = st.iconFilter
            iv.imageAlpha = st.iconAlpha
            val lp = LinearLayout.LayoutParams(st.dp(44), st.dp(44))
            lp.rightMargin = st.dp(16)
            lp.topMargin = st.dp(8)
            previewRow.addView(iv, lp)
            icons.load(app, iv)
        }
    }

    private fun hiddenDialog() {
        if (apps.isEmpty()) return
        val hidden = prefs.hidden.toMutableSet()
        val labels = apps.map { it.label }.toTypedArray()
        val checked = BooleanArray(apps.size) { hidden.contains(apps[it].key) }
        AlertDialog.Builder(this, dlg())
            .setTitle("Hidden apps")
            .setMultiChoiceItems(labels, checked) { _, which, isChecked ->
                if (isChecked) hidden.add(apps[which].key) else hidden.remove(apps[which].key)
            }
            .setPositiveButton("Done") { _, _ -> prefs.hidden = hidden }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun dlg(): Int =
        if (style.dark) android.R.style.Theme_DeviceDefault_Dialog_Alert
        else android.R.style.Theme_DeviceDefault_Light_Dialog_Alert
}
