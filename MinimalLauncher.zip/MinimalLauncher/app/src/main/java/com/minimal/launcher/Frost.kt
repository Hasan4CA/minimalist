package com.minimal.launcher

import android.app.Activity
import android.app.WallpaperManager
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import android.os.Build
import android.view.View
import android.view.WindowInsets
import android.view.WindowInsetsController
import kotlin.math.max

/** Frosted-glass helpers. Android 12+ blurs the wallpaper live on the GPU. */
object Frost {

    fun windowBlurSupported(a: Activity): Boolean =
        Build.VERSION.SDK_INT >= 31 && a.windowManager.isCrossWindowBlurEnabled

    fun set(a: Activity, px: Int) {
        if (Build.VERSION.SDK_INT >= 31) a.window.setBackgroundBlurRadius(px)
    }
}

/** Edge-to-edge window setup shared by the home screen and the settings screen. */
object Sys {

    @Suppress("DEPRECATION")
    fun edgeToEdge(a: Activity, root: View, onInsets: (top: Int, bottom: Int) -> Unit) {
        if (Build.VERSION.SDK_INT >= 30) {
            a.window.setDecorFitsSystemWindows(false)
        } else {
            a.window.decorView.systemUiVisibility =
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                    View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                    View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
        }
        root.setOnApplyWindowInsetsListener { _, ins ->
            val top: Int
            val bottom: Int
            if (Build.VERSION.SDK_INT >= 30) {
                val bars = ins.getInsets(WindowInsets.Type.systemBars())
                val ime = ins.getInsets(WindowInsets.Type.ime())
                top = bars.top
                bottom = max(bars.bottom, ime.bottom)
            } else {
                top = ins.systemWindowInsetTop
                bottom = ins.systemWindowInsetBottom
            }
            onInsets(top, bottom)
            ins
        }
    }

    /** Dark icons on light backgrounds and vice versa. */
    @Suppress("DEPRECATION")
    fun barIcons(a: Activity, dark: Boolean) {
        if (Build.VERSION.SDK_INT >= 30) {
            val mask = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or
                WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
            a.window.insetsController?.setSystemBarsAppearance(if (dark) 0 else mask, mask)
        } else {
            val decor = a.window.decorView
            val light = View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
            decor.systemUiVisibility =
                if (dark) decor.systemUiVisibility and light.inv() else decor.systemUiVisibility or light
        }
    }
}

/**
 * Fallback for phones older than Android 12 (or with blur disabled by battery saver):
 * a heavily down-scaled copy of the wallpaper, scaled back up, gives a soft frosted look
 * for the cost of one tiny bitmap.
 */
object LegacyBlur {

    private val DIVISORS = intArrayOf(1, 10, 18, 30, 48)

    fun make(ctx: Context, level: Int, w: Int, h: Int): Bitmap? {
        return try {
            val wp = WallpaperManager.getInstance(ctx).drawable ?: return null
            val dw = wp.intrinsicWidth
            val dh = wp.intrinsicHeight
            if (dw <= 0 || dh <= 0) return null

            val div = DIVISORS[level.coerceIn(0, DIVISORS.lastIndex)]
            val sw = max(1, w / div)
            val sh = max(1, h / div)
            val small = Bitmap.createBitmap(sw, sh, Bitmap.Config.ARGB_8888)
            val c = Canvas(small)

            val scale = max(sw.toFloat() / dw, sh.toFloat() / dh)
            c.translate((sw - dw * scale) / 2f, (sh - dh * scale) / 2f)
            c.scale(scale, scale)
            (wp as? BitmapDrawable)?.paint?.isFilterBitmap = true
            wp.setBounds(0, 0, dw, dh)
            wp.draw(c)
            small
        } catch (e: Throwable) {
            null // no wallpaper access: the tint layer alone is used
        }
    }
}
