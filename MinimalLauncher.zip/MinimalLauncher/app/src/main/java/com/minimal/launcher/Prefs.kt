package com.minimal.launcher

import android.content.Context
import android.content.SharedPreferences

/** All launcher settings live in one small SharedPreferences file. */
class Prefs(ctx: Context) {

    private val sp: SharedPreferences =
        ctx.applicationContext.getSharedPreferences("launcher", Context.MODE_PRIVATE)

    var theme: Int
        get() = sp.getInt("theme", THEME_SYSTEM)
        set(v) { sp.edit().putInt("theme", v).apply() }

    /** 0 = off, 1 = low, 2 = medium, 3 = high, 4 = max */
    var blurLevel: Int
        get() = sp.getInt("blur", 2).coerceIn(0, 4)
        set(v) { sp.edit().putInt("blur", v.coerceIn(0, 4)).apply() }

    var iconStyle: Int
        get() = sp.getInt("iconStyle", ICON_FADED)
        set(v) { sp.edit().putInt("iconStyle", v).apply() }

    /** 0..100, how strongly icons are faded */
    var iconStrength: Int
        get() = sp.getInt("iconStrength", 50).coerceIn(0, 100)
        set(v) { sp.edit().putInt("iconStrength", v.coerceIn(0, 100)).apply() }

    var font: Int
        get() = sp.getInt("font", 0)
        set(v) { sp.edit().putInt("font", v).apply() }

    var drawerMode: Int
        get() = sp.getInt("drawerMode", MODE_CATEGORIES)
        set(v) { sp.edit().putInt("drawerMode", v).apply() }

    /** Component keys of apps pinned to the home screen, in order. */
    var pinned: List<String>
        get() = sp.getString("pinned", "")!!.split(",").filter { it.isNotEmpty() }
        set(v) { sp.edit().putString("pinned", v.joinToString(",")).apply() }

    var hidden: Set<String>
        get() = HashSet(sp.getStringSet("hidden", emptySet())!!)
        set(v) { sp.edit().putStringSet("hidden", HashSet(v)).apply() }

    /** Category names the user has collapsed in the drawer. */
    var collapsed: Set<String>
        get() = HashSet(sp.getStringSet("collapsed", emptySet())!!)
        set(v) { sp.edit().putStringSet("collapsed", HashSet(v)).apply() }

    fun categoryOf(key: String): String? = sp.getString("cat_$key", null)

    fun setCategory(key: String, category: String?) {
        val e = sp.edit()
        if (category == null) e.remove("cat_$key") else e.putString("cat_$key", category)
        e.apply()
    }

    fun clearCategories() {
        val e = sp.edit()
        sp.all.keys.filter { it.startsWith("cat_") }.forEach { e.remove(it) }
        e.apply()
    }

    /** Changes when anything that affects colours, fonts, icons or blur changes. */
    fun styleKey(): String = "$theme|$blurLevel|$iconStyle|$iconStrength|$font"

    companion object {
        const val THEME_SYSTEM = 0
        const val THEME_LIGHT = 1
        const val THEME_DARK = 2

        const val ICON_ORIGINAL = 0
        const val ICON_FADED = 1
        const val ICON_MONO = 2

        const val MODE_CATEGORIES = 0
        const val MODE_AZ = 1

        const val MAX_PINNED = 6
    }
}
