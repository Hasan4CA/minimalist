package com.minimal.launcher

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.util.LruCache
import android.widget.ImageView

/**
 * Loads app icons lazily on the background thread into a small, hard-capped cache (4 MB),
 * so memory use stays flat no matter how many apps are installed.
 */
class IconLoader(ctx: Context, private val sizePx: Int) {

    private val pm = ctx.applicationContext.packageManager

    private val cache = object : LruCache<String, Bitmap>(4 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount
    }

    fun load(app: AppInfo, view: ImageView) {
        view.tag = app.key
        val hit = cache.get(app.key)
        if (hit != null) {
            view.setImageBitmap(hit)
            return
        }
        view.setImageDrawable(null)
        Bg.run {
            // the row may already have been recycled for another app while we waited
            if (view.tag != app.key) return@run
            val bmp = render(app)
            cache.put(app.key, bmp)
            view.post {
                if (view.tag == app.key) view.setImageBitmap(bmp)
            }
        }
    }

    private fun render(app: AppInfo): Bitmap {
        val bmp = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888)
        try {
            val d = pm.getActivityIcon(app.component)
            d.setBounds(0, 0, sizePx, sizePx)
            d.draw(Canvas(bmp))
        } catch (e: Exception) {
            // leave a blank icon rather than failing
        }
        return bmp
    }
}
