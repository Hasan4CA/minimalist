package com.minimal.launcher

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView

/** One line in the app drawer: either a section header or an app. */
sealed class Row {
    /** count < 0 means "don't show a count" (used for A-Z letters). */
    data class Header(
        val title: String,
        val count: Int,
        val collapsed: Boolean,
        val collapsible: Boolean
    ) : Row()

    data class App(val app: AppInfo) : Row()
}

class DrawerAdapter(
    private val ctx: Context,
    private val style: Style,
    private val icons: IconLoader
) : BaseAdapter() {

    var rows: List<Row> = emptyList()
        private set

    fun submit(r: List<Row>) {
        rows = r
        notifyDataSetChanged()
    }

    override fun getCount(): Int = rows.size
    override fun getItem(position: Int): Any = rows[position]
    override fun getItemId(position: Int): Long = position.toLong()
    override fun getViewTypeCount(): Int = 2
    override fun getItemViewType(position: Int): Int = if (rows[position] is Row.Header) 0 else 1

    private class Holder(val icon: ImageView, val name: TextView)

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val r = rows[position]
        if (r is Row.Header) {
            val tv = (convertView as? TextView) ?: newHeader()
            tv.text = headerText(r)
            return tv
        }
        val app = (r as Row.App).app
        val row = convertView ?: newRow()
        val h = row.tag as Holder
        h.name.text = app.label
        icons.load(app, h.icon)
        return row
    }

    private fun headerText(h: Row.Header): String {
        val t = h.title.uppercase()
        return when {
            h.count < 0 -> t
            h.collapsed -> "$t  ·  ${h.count}  +"
            else -> "$t  ·  ${h.count}"
        }
    }

    private fun newHeader(): TextView {
        val tv = style.label(ctx, "", 12f, style.textDim)
        tv.letterSpacing = 0.12f
        tv.setPadding(style.dp(28), style.dp(22), style.dp(28), style.dp(6))
        return tv
    }

    private fun newRow(): View {
        val row = LinearLayout(ctx)
        row.orientation = LinearLayout.HORIZONTAL
        row.gravity = Gravity.CENTER_VERTICAL
        row.setPadding(style.dp(28), style.dp(10), style.dp(36), style.dp(10))
        row.background = style.pressed()

        val icon = ImageView(ctx)
        icon.colorFilter = style.iconFilter
        icon.imageAlpha = style.iconAlpha
        row.addView(icon, LinearLayout.LayoutParams(style.dp(40), style.dp(40)))

        val name = style.label(ctx, "", 17f, style.text)
        val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        lp.leftMargin = style.dp(18)
        row.addView(name, lp)

        row.tag = Holder(icon, name)
        return row
    }
}

/** Thin A-Z strip on the right edge of the drawer for fast scrolling. */
class IndexBar(ctx: Context, style: Style) : View(ctx) {

    var letters: List<String> = emptyList()
        set(v) {
            field = v
            invalidate()
        }

    var onPick: ((String) -> Unit)? = null

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    init {
        paint.color = style.textDim
        paint.textSize = style.dp(11).toFloat()
        paint.typeface = style.typeface
        paint.textAlign = Paint.Align.CENTER
    }

    override fun onDraw(canvas: Canvas) {
        val n = letters.size
        if (n == 0) return
        val step = height.toFloat() / n
        val centerOffset = (paint.descent() + paint.ascent()) / 2f
        for (i in 0 until n) {
            canvas.drawText(letters[i], width / 2f, step * i + step / 2f - centerOffset, paint)
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE -> {
                parent.requestDisallowInterceptTouchEvent(true)
                if (letters.isNotEmpty() && height > 0) {
                    val i = (e.y / height * letters.size).toInt().coerceIn(0, letters.size - 1)
                    onPick?.invoke(letters[i])
                }
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> return true
        }
        return super.onTouchEvent(e)
    }
}
