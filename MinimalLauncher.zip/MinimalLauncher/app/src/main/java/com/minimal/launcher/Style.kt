package com.minimal.launcher

import android.content.Context
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.StateListDrawable
import android.util.TypedValue
import android.widget.TextView

/** Fonts built into Android, so the launcher ships no font files at all. */
object Fonts {
    val LABELS = arrayOf("Default", "Light", "Thin", "Condensed", "Serif", "Monospace", "Casual", "Cursive")
    private val FAMILIES = arrayOf(
        "sans-serif", "sans-serif-light", "sans-serif-thin", "sans-serif-condensed",
        "serif", "monospace", "casual", "cursive"
    )

    fun typeface(i: Int): Typeface =
        Typeface.create(FAMILIES[i.coerceIn(0, FAMILIES.lastIndex)], Typeface.NORMAL)
}

/** Everything visual, computed once from the saved settings. */
class Style(ctx: Context, prefs: Prefs) {

    private val density = ctx.resources.displayMetrics.density

    val dark: Boolean = when (prefs.theme) {
        Prefs.THEME_LIGHT -> false
        Prefs.THEME_DARK -> true
        else -> (ctx.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) ==
            Configuration.UI_MODE_NIGHT_YES
    }

    // ---- colours
    val text: Int = if (dark) 0xF2FFFFFF.toInt() else 0xEB111418.toInt()
    val textDim: Int = if (dark) 0x99FFFFFF.toInt() else 0x99111418.toInt()
    val textFaint: Int = if (dark) 0x59FFFFFF.toInt() else 0x59111418.toInt()
    val frostColor: Int = if (dark) 0xFF0E1216.toInt() else 0xFFF3F6F9.toInt()

    // ---- blur / frost
    val blurLevel: Int = prefs.blurLevel
    val blurPx: Int = BLUR_RADII[blurLevel]

    /** Opacity (0..1) of the tint layer on the home screen and in the drawer. */
    val scrimHome: Float = (if (dark) HOME_DARK else HOME_LIGHT)[blurLevel]
    val scrimDrawer: Float = (if (dark) DRAWER_DARK else DRAWER_LIGHT)[blurLevel]

    // ---- fonts
    val typeface: Typeface = Fonts.typeface(prefs.font)
    val clockTypeface: Typeface =
        if (prefs.font == 0) Typeface.create("sans-serif-light", Typeface.NORMAL) else typeface

    // ---- icons
    private val iconStyle = prefs.iconStyle
    private val strength = prefs.iconStrength / 100f

    val iconAlpha: Int =
        if (iconStyle == Prefs.ICON_ORIGINAL) 255 else (255 - 90 * strength).toInt()

    val iconFilter: ColorFilter? = if (iconStyle == Prefs.ICON_ORIGINAL) {
        null
    } else {
        val sat = if (iconStyle == Prefs.ICON_MONO) 0f else 1f - 0.8f * strength
        val cm = ColorMatrix()
        cm.setSaturation(sat)
        if (dark) {
            // lift brightness a little so faded icons stay visible on dark backgrounds
            cm.postConcat(
                ColorMatrix(
                    floatArrayOf(
                        1.15f, 0f, 0f, 0f, 6f,
                        0f, 1.15f, 0f, 0f, 6f,
                        0f, 0f, 1.15f, 0f, 6f,
                        0f, 0f, 0f, 1f, 0f
                    )
                )
            )
        }
        ColorMatrixColorFilter(cm)
    }

    fun dp(v: Int): Int = (v * density + 0.5f).toInt()

    fun label(ctx: Context, s: CharSequence, sp: Float, color: Int, face: Typeface = typeface): TextView {
        val tv = TextView(ctx)
        tv.text = s
        tv.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp)
        tv.setTextColor(color)
        tv.typeface = face
        tv.includeFontPadding = false
        return tv
    }

    /** Subtle press feedback for list rows. */
    fun pressed(): StateListDrawable {
        val d = StateListDrawable()
        d.addState(intArrayOf(android.R.attr.state_pressed), ColorDrawable((text and 0x00FFFFFF) or 0x1A000000))
        d.addState(intArrayOf(), ColorDrawable(Color.TRANSPARENT))
        return d
    }

    companion object {
        /** Window blur radius in pixels for Off / Low / Medium / High / Max. */
        val BLUR_RADII = intArrayOf(0, 14, 30, 55, 95)
        val BLUR_LABELS = arrayOf("Off", "Low", "Medium", "High", "Max")

        private val HOME_DARK = floatArrayOf(0.38f, 0.12f, 0.16f, 0.20f, 0.24f)
        private val HOME_LIGHT = floatArrayOf(0.34f, 0.14f, 0.18f, 0.22f, 0.26f)
        private val DRAWER_DARK = floatArrayOf(0.66f, 0.34f, 0.42f, 0.52f, 0.60f)
        private val DRAWER_LIGHT = floatArrayOf(0.62f, 0.38f, 0.48f, 0.58f, 0.66f)
    }
}
