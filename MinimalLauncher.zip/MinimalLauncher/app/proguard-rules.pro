# No special rules needed: the app uses no reflection and no third-party libraries.
